import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ProductCard from './Components/ProductCard'

function App() {
 

  return (
    <>
      <ProductCard/>
    </>
  )
}

export default App
